package com.bookticket;

import com.bookticket.business.service.ScreeningServiceIntegrationTest;
import com.bookticket.data.repository.ScreeningRepositoryIntegrationTest;
import com.bookticket.web.application.ScreeningControllerIntegrationTest;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({ScreeningServiceIntegrationTest.class, ScreeningControllerIntegrationTest.class,
        ScreeningRepositoryIntegrationTest.class})
public class MovieScreeningTestSuite {
}
