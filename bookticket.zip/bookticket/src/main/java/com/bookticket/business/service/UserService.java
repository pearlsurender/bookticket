package com.bookticket.business.service;

import com.bookticket.data.entity.User;

public interface UserService {
    void save(User user);

    User findByUsername(String username);
}
